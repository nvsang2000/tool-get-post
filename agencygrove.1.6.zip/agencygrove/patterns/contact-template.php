<?php
/**
 * Title: Contact Us Page
 * Slug: agencygrove/contact-template
 * Categories: agencygrove
 * Keywords: contact
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
<!-- wp:pattern {"slug":"agencygrove/contact"} /-->
<!-- wp:pattern {"slug":"agencygrove/team"} /-->
<!-- wp:pattern {"slug":"agencygrove/about"} /-->
<!-- wp:pattern {"slug":"agencygrove/brands"} /-->