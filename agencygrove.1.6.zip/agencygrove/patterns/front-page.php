<?php
/**
 * Title: Front Page
 * Slug: agencygrove/front-page
 * Categories: agencygrove
 * Keywords: front-page
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
<!-- wp:pattern {"slug":"agencygrove/banner"} /-->
<!-- wp:pattern {"slug":"agencygrove/brands"} /-->
<!-- wp:pattern {"slug":"agencygrove/services"} /-->
<!-- wp:pattern {"slug":"agencygrove/about"} /-->
<!-- wp:pattern {"slug":"agencygrove/portfolio"} /-->
<!-- wp:pattern {"slug":"agencygrove/team"} /-->
<!-- wp:pattern {"slug":"agencygrove/testimonials"} /-->
<!-- wp:pattern {"slug":"agencygrove/articles-style-two"} /-->