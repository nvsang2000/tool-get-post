<?php
/**
 * Title: Our Services Page
 * Slug: agencygrove/services-template
 * Categories: agencygrove
 * Keywords: services
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
<!-- wp:pattern {"slug":"agencygrove/services"} /-->
<!-- wp:pattern {"slug":"agencygrove/pricing-plan"} /-->
<!-- wp:pattern {"slug":"agencygrove/portfolio"} /-->
<!-- wp:pattern {"slug":"agencygrove/brands"} /-->
<!-- wp:pattern {"slug":"agencygrove/testimonials"} /-->
