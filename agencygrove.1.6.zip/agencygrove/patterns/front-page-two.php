<?php
/**
 * Title: Front Page Two
 * Slug: agencygrove/front-page-two
 * Categories: agencygrove
 * Keywords: front-page
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
<!-- wp:pattern {"slug":"agencygrove/banner-style-two"} /-->
<!-- wp:pattern {"slug":"agencygrove/counter-style-two"} /-->
<!-- wp:pattern {"slug":"agencygrove/contact-with-icon"} /-->
<!-- wp:pattern {"slug":"agencygrove/contact"} /-->
<!-- wp:pattern {"slug":"agencygrove/cta"} /-->
<!-- wp:pattern {"slug":"agencygrove/faq"} /-->
